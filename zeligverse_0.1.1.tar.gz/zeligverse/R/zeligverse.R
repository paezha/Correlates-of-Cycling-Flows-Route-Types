#' @keywords internal
"_PACKAGE"

# Suppress R CMD check note
#' @importFrom Zelig zelig
#' @import ZeligChoice
#' @import ZeligEI
NULL
