library(testthat)
library(zeligverse)

test_check("zeligverse")
