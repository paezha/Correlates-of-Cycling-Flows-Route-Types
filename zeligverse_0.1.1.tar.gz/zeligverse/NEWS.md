# zeligverse 0.1.1

*   Added Amelia, MatchIt, and WhatIf packages.

# zeligverse 0.1.0

*   Initial release. On load, zeligverse loads (core) Zelig, ZeligEI, and
ZeligChoice.
